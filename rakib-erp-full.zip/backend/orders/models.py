from django.db import models

class Order(models.Model):
    order_no = models.CharField(max_length=50, unique=True)
    buyer_name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField()
    order_date = models.DateField()

    def __str__(self):
        return f"Order {self.order_no} - {self.buyer_name}"