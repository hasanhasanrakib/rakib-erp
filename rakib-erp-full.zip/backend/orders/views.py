from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Order
from .serializers import OrderSerializer
import csv
from django.http import HttpResponse
from datetime import datetime

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all().order_by('-order_date')
    serializer_class = OrderSerializer

    @action(detail=False, methods=['get'])
    def export_csv(self, request):
        response = HttpResponse(content_type='text/csv')
        filename = 'orders_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv'
        response['Content-Disposition'] = f'attachment; filename="{filename}"'

        writer = csv.writer(response)
        writer.writerow(['Order No', 'Buyer Name', 'Quantity', 'Order Date'])
        for order in self.get_queryset():
            writer.writerow([order.order_no, order.buyer_name, order.quantity, order.order_date])

        return response