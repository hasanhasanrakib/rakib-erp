import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [orders, setOrders] = useState([]);
  const [form, setForm] = useState({
    order_no: '',
    buyer_name: '',
    quantity: '',
    order_date: ''
  });

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = () => {
    axios.get('http://localhost:8000/api/orders/')
      .then(res => setOrders(res.data))
      .catch(err => console.error(err));
  };

  const handleChange = (e) => {
    setForm({...form, [e.target.name]: e.target.value});
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8000/api/orders/', form)
      .then(() => {
        fetchOrders();
        setForm({order_no:'', buyer_name:'', quantity:'', order_date:''});
      })
      .catch(err => alert('Error: ' + err));
  };

  const handleExport = () => {
    window.open('http://localhost:8000/api/orders/export_csv/', '_blank');
  };

  return (
    <div style={{padding:20}}>
      <h1>Order Entry</h1>
      <form onSubmit={handleSubmit} style={{marginBottom:20}}>
        <input type="text" name="order_no" placeholder="Order No" value={form.order_no} onChange={handleChange} required />
        <input type="text" name="buyer_name" placeholder="Buyer Name" value={form.buyer_name} onChange={handleChange} required />
        <input type="number" name="quantity" placeholder="Quantity" value={form.quantity} onChange={handleChange} required />
        <input type="date" name="order_date" placeholder="Order Date" value={form.order_date} onChange={handleChange} required />
        <button type="submit">Add Order</button>
      </form>
      <button onClick={handleExport}>Export to CSV</button>
      <h2>Orders List</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Order No</th>
            <th>Buyer Name</th>
            <th>Quantity</th>
            <th>Order Date</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(o => (
            <tr key={o.id}>
              <td>{o.order_no}</td>
              <td>{o.buyer_name}</td>
              <td>{o.quantity}</td>
              <td>{o.order_date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;